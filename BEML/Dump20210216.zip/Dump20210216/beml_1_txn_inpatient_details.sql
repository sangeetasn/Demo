-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: beml_1
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `txn_inpatient_details`
--

DROP TABLE IF EXISTS `txn_inpatient_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `txn_inpatient_details` (
  `INPAITENT_ID` int(11) NOT NULL,
  `BILL_AMT` varchar(45) NOT NULL,
  `BILL_DT` varchar(45) DEFAULT NULL,
  `HOSPITAL_NO` varchar(45) NOT NULL,
  `Age` varchar(45) DEFAULT NULL,
  `SEX` varchar(45) DEFAULT NULL,
  `INPAITENT_NO` varchar(45) DEFAULT NULL,
  `ADDRESS` varchar(45) DEFAULT NULL,
  `ADMISSION_DT` varchar(45) DEFAULT NULL,
  `WARD` varchar(45) DEFAULT NULL,
  `ADMISSION_TIME` varchar(45) DEFAULT NULL,
  `BED` varchar(45) NOT NULL,
  `DISCHARGE_DT` varchar(45) DEFAULT NULL,
  `DEPT` varchar(45) DEFAULT NULL,
  `DISCHARGE_TIME` varchar(45) DEFAULT NULL,
  `NO_OF_DAYS` varchar(45) DEFAULT NULL,
  `DOCTOR` varchar(45) DEFAULT NULL,
  `GSTIN` varchar(45) DEFAULT NULL,
  `PAN_NO` varchar(45) DEFAULT NULL,
  `BILL_NO` varchar(45) DEFAULT NULL,
  `PAYOR` varchar(45) DEFAULT NULL,
  `AUTH_CODE` varchar(45) DEFAULT NULL,
  `FILE_PATH` varchar(45) DEFAULT NULL,
  `FILE_RECEIVED_DT` varchar(45) DEFAULT NULL,
  `CREATED_DT` varchar(45) DEFAULT NULL,
  `CREATED_BY` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `UPDATED_DT` varchar(45) DEFAULT NULL,
  `UPDATED_BY` varchar(45) DEFAULT NULL,
  `Received_FROM` varchar(45) DEFAULT NULL,
  `USER_ID` varchar(45) DEFAULT NULL,
  `EMP_ID` varchar(45) DEFAULT NULL,
  `Status` varchar(45) DEFAULT NULL,
  `EXCLUDE_AMT` varchar(45) DEFAULT NULL,
  `DISCOUNTED_SUM` varchar(45) DEFAULT NULL,
  `CAP_AMT` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`INPAITENT_ID`),
  UNIQUE KEY `USER_ID_UNIQUE` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `txn_inpatient_details`
--

LOCK TABLES `txn_inpatient_details` WRITE;
/*!40000 ALTER TABLE `txn_inpatient_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `txn_inpatient_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-16 10:21:48
