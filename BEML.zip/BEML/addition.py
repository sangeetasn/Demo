def addition(a, b):
    return (a+b)#call te function