def printme(str):
    print(str)
    return str